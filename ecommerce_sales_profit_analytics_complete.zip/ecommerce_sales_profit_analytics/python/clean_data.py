import pandas as pd
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
raw = BASE / "data" / "ecommerce_sales_raw.csv"
out = BASE / "data" / "ecommerce_sales_clean.csv"

df = pd.read_csv(raw)
df["order_date"] = pd.to_datetime(df["order_date"], errors="coerce")
df["quantity"] = pd.to_numeric(df["quantity"], errors="coerce")
df["unit_price"] = pd.to_numeric(df["unit_price"], errors="coerce")
df["unit_cost"] = pd.to_numeric(df["unit_cost"], errors="coerce")
df["discount_pct"] = pd.to_numeric(df["discount_pct"], errors="coerce")

df = df.drop_duplicates()
df = df.dropna(subset=["order_id","order_date","product","quantity","unit_price","unit_cost"])
df = df[(df["quantity"] > 0) & (df["unit_price"] >= 0) & (df["unit_cost"] >= 0)]
df["gross_sales"] = df["quantity"] * df["unit_price"]
df["discount_amount"] = df["gross_sales"] * df["discount_pct"]
df["net_sales"] = df["gross_sales"] - df["discount_amount"]
df["total_cost"] = df["quantity"] * df["unit_cost"]
df["profit"] = df["net_sales"] - df["total_cost"]
df["profit_margin_pct"] = (df["profit"] / df["net_sales"]).where(df["net_sales"] != 0, 0) * 100
df["year_month"] = df["order_date"].dt.to_period("M").astype(str)

df.to_csv(out, index=False)
print(f"Cleaned dataset saved to: {out}")
print(f"Rows: {len(df)}")
print(df.head())
