# E-commerce Sales & Profit Analytics

## Project Overview
This project analyzes e-commerce sales, costs, discounts and profitability using Python, SQL, Excel and Power BI.

## Business Questions
- What are total sales and profit?
- Which category generates the most revenue?
- Which products are top performers?
- Which cities perform best?
- Is Online or Retail more profitable?
- How does sales performance change month by month?
- Which categories have the best profit margins?

## Technology Stack
- Python: Pandas
- SQL: MySQL-compatible SQL
- Excel: data inspection and validation
- Power BI: dashboard and DAX

## Folder Structure
```text
ecommerce_sales_profit_analytics/
├── data/
│   ├── ecommerce_sales_raw.csv
│   └── ecommerce_sales_clean.csv
├── python/
│   └── clean_data.py
├── sql/
│   ├── schema.sql
│   └── queries.sql
├── powerbi/
│   ├── dax_measures.txt
│   └── kpi_and_layout.txt
├── docs/
│   └── README.md
└── README.md
```

## How to Run

### 1. Python
Install Pandas:
```bash
pip install pandas
```

Run:
```bash
python python/clean_data.py
```

### 2. SQL
Create the database and table with `sql/schema.sql`.
Import `data/ecommerce_sales_clean.csv` into the `sales` table.
Run queries from `sql/queries.sql`.

### 3. Power BI
Open Power BI Desktop.
Select **Get Data → Text/CSV** and load `ecommerce_sales_clean.csv`.
Create the DAX measures from `powerbi/dax_measures.txt`.
Add the KPI cards, charts and slicers described in `powerbi/kpi_and_layout.txt`.

## Expected Portfolio Outcome
The final dashboard should allow a recruiter to see:
- revenue performance
- profitability
- product/category performance
- geographic performance
- sales channel performance
- monthly trends

## Resume Description
**E-commerce Sales & Profit Analytics Dashboard**
Built an end-to-end analytics project using Python, SQL and Power BI to clean transactional sales data, calculate revenue and profitability metrics, analyze product/category/city performance, and develop an interactive dashboard with DAX-based KPIs and business insights.

## Interview Explanation
"I collected transactional sales data, cleaned and validated it using Pandas, stored and analyzed it using SQL, and then connected the cleaned data to Power BI. I created DAX measures for sales, cost, profit, profit margin, orders and average order value. Finally, I built an interactive dashboard with filters for date, category, city and sales channel."
