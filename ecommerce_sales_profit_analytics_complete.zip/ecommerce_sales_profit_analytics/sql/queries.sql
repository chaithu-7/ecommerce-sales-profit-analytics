USE ecommerce_analytics;

-- 1. Total sales, cost and profit
SELECT ROUND(SUM(quantity * unit_price * (1-discount_pct)),2) AS total_sales,
       ROUND(SUM(quantity * unit_cost),2) AS total_cost,
       ROUND(SUM(quantity * unit_price * (1-discount_pct)) - SUM(quantity * unit_cost),2) AS total_profit
FROM sales;

-- 2. Sales by category
SELECT category,
       ROUND(SUM(quantity * unit_price * (1-discount_pct)),2) AS sales
FROM sales
GROUP BY category
ORDER BY sales DESC;

-- 3. Profit by category
SELECT category,
       ROUND(SUM(quantity * unit_price * (1-discount_pct)) - SUM(quantity * unit_cost),2) AS profit
FROM sales
GROUP BY category
ORDER BY profit DESC;

-- 4. Top 10 products by sales
SELECT product,
       ROUND(SUM(quantity * unit_price * (1-discount_pct)),2) AS sales
FROM sales
GROUP BY product
ORDER BY sales DESC
LIMIT 10;

-- 5. Monthly sales
SELECT DATE_FORMAT(order_date,'%Y-%m') AS month,
       ROUND(SUM(quantity * unit_price * (1-discount_pct)),2) AS sales
FROM sales
GROUP BY month
ORDER BY month;

-- 6. City performance
SELECT city,
       ROUND(SUM(quantity * unit_price * (1-discount_pct)),2) AS sales,
       ROUND(SUM(quantity * unit_price * (1-discount_pct)) - SUM(quantity * unit_cost),2) AS profit
FROM sales
GROUP BY city
ORDER BY sales DESC;

-- 7. Online vs Retail
SELECT sales_channel,
       ROUND(SUM(quantity * unit_price * (1-discount_pct)),2) AS sales,
       ROUND(SUM(quantity * unit_price * (1-discount_pct)) - SUM(quantity * unit_cost),2) AS profit
FROM sales
GROUP BY sales_channel;

-- 8. Profit margin by category
SELECT category,
       ROUND(
         100 * (SUM(quantity * unit_price * (1-discount_pct)) - SUM(quantity * unit_cost))
         / NULLIF(SUM(quantity * unit_price * (1-discount_pct)),0), 2
       ) AS profit_margin_pct
FROM sales
GROUP BY category
ORDER BY profit_margin_pct DESC;
