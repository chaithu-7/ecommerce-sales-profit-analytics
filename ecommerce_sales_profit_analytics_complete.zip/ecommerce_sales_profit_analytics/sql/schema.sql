CREATE DATABASE ecommerce_analytics;
USE ecommerce_analytics;

CREATE TABLE sales (
    order_id VARCHAR(20) PRIMARY KEY,
    order_date DATE NOT NULL,
    city VARCHAR(50),
    category VARCHAR(50),
    product VARCHAR(100),
    quantity INT NOT NULL,
    unit_price DECIMAL(12,2) NOT NULL,
    unit_cost DECIMAL(12,2) NOT NULL,
    discount_pct DECIMAL(5,2) NOT NULL,
    sales_channel VARCHAR(30)
);

-- Import ecommerce_sales_clean.csv using your SQL tool's CSV import option.
